<?php

namespace App\Containers\Option\UserStatus\Exceptions;

use App\Ship\Core\Abstracts\Exceptions\Exception;

class UserStatusExistsException extends Exception
{
    //
}
